var structhw__behavior =
[
    [ "freq", "d2/d14/structhw__behavior.html#a15a6c431438c008ce2672656b5a4a583", null ],
    [ "island", "d2/d14/structhw__behavior.html#adad570bd0c0f4060c4d4ecf99e885443", null ],
    [ "num_tuples", "d2/d14/structhw__behavior.html#ac83f8164c20d9aa20c462fd8fd990a11", null ],
    [ "speed", "d2/d14/structhw__behavior.html#a77e76354533e34460e9f05e334370869", null ],
    [ "speed_level", "d2/d14/structhw__behavior.html#a2a245a764551a3e7c3ae7ccdcdeda984", null ],
    [ "volts", "d2/d14/structhw__behavior.html#a2d0001b4196c481910d7e12b09d8efef", null ]
];