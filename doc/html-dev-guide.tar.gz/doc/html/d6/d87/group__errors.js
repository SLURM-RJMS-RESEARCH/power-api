var group__errors =
[
    [ "PWR_ALREADY_INITIALIZED", "d6/d87/group__errors.html#ga1aa775ae015e614d30ed9202265d2b5b", null ],
    [ "PWR_ALREADY_MINMAX", "d6/d87/group__errors.html#gad324597788238856a1ce4101922881cd", null ],
    [ "PWR_ARCH_UNSUPPORTED", "d6/d87/group__errors.html#gacf343887621e724612fb82ccf8f15787", null ],
    [ "PWR_DVFS_ERR", "d6/d87/group__errors.html#ga1d8b09083314538e573b8db3dc9e1afe", null ],
    [ "PWR_ERR", "d6/d87/group__errors.html#gaccb327661fe37a32a72d74d7f681a938", null ],
    [ "PWR_FINAL_ERR", "d6/d87/group__errors.html#ga775b870544a028d539552c6c10d3ebdb", null ],
    [ "PWR_INIT_ERR", "d6/d87/group__errors.html#ga1044f218420811a265143af9e62fbdd5", null ],
    [ "PWR_INVALID_ISLAND", "d6/d87/group__errors.html#gaa3633dc41c8bed5024b89606f7679f92", null ],
    [ "PWR_IO_ERR", "d6/d87/group__errors.html#gab851389a103bfd3ab9d8a3ac3678bf0b", null ],
    [ "PWR_OK", "d6/d87/group__errors.html#ga982b67b9fcf75c6999ed8cc5ee4e250f", null ],
    [ "PWR_OVER_E_BUDGET", "d6/d87/group__errors.html#ga1d1e97ad1f901303b8a06231bd95ab00", null ],
    [ "PWR_OVER_P_BUDGET", "d6/d87/group__errors.html#ga543128b71e45a72dc65a40678e8eccc0", null ],
    [ "PWR_OVER_T_BUDGET", "d6/d87/group__errors.html#ga63079a57f2b5e9aa0cb1c9d74927f73d", null ],
    [ "PWR_REQUEST_DENIED", "d6/d87/group__errors.html#ga6ce0662b03877b5e7f4afc2fc0d66c51", null ],
    [ "PWR_UNAVAILABLE", "d6/d87/group__errors.html#gad37957bf6f92698c57b9cd42e749b970", null ],
    [ "PWR_UNIMPLEMENTED", "d6/d87/group__errors.html#gaa4d9ad58920d8c9b756b3379d356907a", null ],
    [ "PWR_UNINITIALIZED", "d6/d87/group__errors.html#ga97ad95a761d8e762861f5bb8dcb000b6", null ],
    [ "PWR_UNSUPPORTED_SPEED_LEVEL", "d6/d87/group__errors.html#ga496d369bd5ebec135af895376acdf7e1", null ],
    [ "PWR_UNSUPPORTED_VOLTAGE", "d6/d87/group__errors.html#gafe589ddc5a955f7d454528de9a949e9a", null ]
];