var internals_8h =
[
    [ "phys_island", "d4/d71/structphys__island.html", "d4/d71/structphys__island" ],
    [ "pwr_ctx", "de/dd9/structpwr__ctx.html", "de/dd9/structpwr__ctx" ],
    [ "phys_island_t", "dd/da3/internals_8h.html#add1e9e6440d7590b588db137d21e106c", null ],
    [ "pwr_ctx_t", "dd/da3/internals_8h.html#a2038ec2c8e157a4a07ff96838ed72026", null ],
    [ "pwr_err_t", "dd/da3/internals_8h.html#a46d3260cd04eb982b5ba6f5c4ee5678f", null ],
    [ "free_energy_data", "dd/da3/internals_8h.html#a72f30110ff9b769cf79768652e5bdc63", null ],
    [ "free_speed_data", "dd/da3/internals_8h.html#a62ee8639a1af10734e5c356a0e108cd3", null ],
    [ "free_structure_data", "dd/da3/internals_8h.html#a5068e8aba4eeefe8d9a0f431464ecb8c", null ],
    [ "init_energy", "dd/da3/internals_8h.html#a88d17493f557c4f8b69f3d68d38a587b", null ],
    [ "init_speed_levels", "dd/da3/internals_8h.html#aabd446883e3dfacb5c5327a06b508cf4", null ],
    [ "init_struct_module", "dd/da3/internals_8h.html#af9ba1c381cd94c00d7a9c7d11358e35d", null ],
    [ "sysfs_filename", "dd/da3/internals_8h.html#a5e90fde5437178cce4b98a6e0a0773ff", null ]
];