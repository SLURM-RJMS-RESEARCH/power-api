var modules =
[
    [ "Limitations", "d3/dee/group__limits.html", "d3/dee/group__limits" ],
    [ "Error Codes", "d6/d87/group__errors.html", "d6/d87/group__errors" ],
    [ "Units", "d7/d34/group__units.html", "d7/d34/group__units" ],
    [ "Modules", "dc/dd2/group__modules.html", "dc/dd2/group__modules" ],
    [ "Initialization code", "d9/d54/group__init.html", "d9/d54/group__init" ]
];