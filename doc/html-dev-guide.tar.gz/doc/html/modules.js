var modules =
[
    [ "Limitations", "d3/dee/group__limits.html", null ],
    [ "Speed Levels", "d0/da1/group__speed__control.html", null ],
    [ "Speed Policies", "d1/de1/group__speed__policies.html", null ],
    [ "Scheduling Policies", "d6/da0/group__scheduling__policies.html", null ],
    [ "Unique Identifiers", "da/d2d/group__id.html", null ],
    [ "Units", "d7/d34/group__units.html", null ],
    [ "High-Level Interface Data Structures", "dc/d98/group__hli.html", "dc/d98/group__hli" ],
    [ "Error Codes", "d6/d87/group__errors.html", null ],
    [ "High-Level Interface", "de/def/group__highlevel.html", "de/def/group__highlevel" ],
    [ "Low-Level Interface", "d5/de9/group__lowlevel.html", "d5/de9/group__lowlevel" ]
];