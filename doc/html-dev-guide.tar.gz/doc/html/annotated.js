var annotated =
[
    [ "phys_island", "d4/d71/structphys__island.html", "d4/d71/structphys__island" ],
    [ "pwr_ctx", "de/dd9/structpwr__ctx.html", "de/dd9/structpwr__ctx" ],
    [ "pwr_emeas_t", "d3/d10/structpwr__emeas__t.html", "d3/d10/structpwr__emeas__t" ]
];