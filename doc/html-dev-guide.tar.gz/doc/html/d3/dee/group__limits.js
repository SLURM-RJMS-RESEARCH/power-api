var group__limits =
[
    [ "PWR_MAX_CPU_PER_PHYS_ISLAND", "d3/dee/group__limits.html#gadfe271739f5c0bf4a5430a8e86b706f5", null ],
    [ "PWR_MAX_CPU_PER_VIRT_ISLAND", "d3/dee/group__limits.html#ga9b7e5813c2aaf0a77bf787197744a216", null ],
    [ "PWR_MAX_PHYS_CPU", "d3/dee/group__limits.html#gadfa5fef860755eeccb6c0acf0717b38f", null ],
    [ "PWR_MAX_PHYS_ISLANDS", "d3/dee/group__limits.html#ga5533fbd5ad3988d78d3bd155b6dfe6d6", null ],
    [ "PWR_MAX_SPEED_LEVELS", "d3/dee/group__limits.html#gab6ef89ea7523a640a2a4bb23e1c5781f", null ],
    [ "PWR_MAX_VIRT_ISLANDS", "d3/dee/group__limits.html#ga31e877ff5853c6e258dc2a65588f06e9", null ]
];