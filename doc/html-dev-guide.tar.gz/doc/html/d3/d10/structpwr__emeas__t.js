var structpwr__emeas__t =
[
    [ "duration", "d3/d10/structpwr__emeas__t.html#a11b4f61f7dadc5e76129e1d30bb9ecc1", null ],
    [ "names", "d3/d10/structpwr__emeas__t.html#a9529725765a6ad5b7783528e7a68e962", null ],
    [ "nbValues", "d3/d10/structpwr__emeas__t.html#a8cb45a46026ec0569a061c971792423b", null ],
    [ "units", "d3/d10/structpwr__emeas__t.html#a43c914d88d7ac71474621ade4e4bacfe", null ],
    [ "values", "d3/d10/structpwr__emeas__t.html#aa98aeff03e7d721ccbfe0cd9adbfbe58", null ]
];