var group__highlevel_dup =
[
    [ "pwr_change_hw_behavior", "de/def/group__highlevel.html#gae84ec3073afea8cd057ef0424c0d793d", null ],
    [ "pwr_ecount_finalize", "de/def/group__highlevel.html#gad9e570216a36266881f673ab1b0f4fea", null ],
    [ "pwr_finalize", "de/def/group__highlevel.html#gaaa57a34521dd6825ebf51912510c8cb9", null ],
    [ "pwr_hw_behavior", "de/def/group__highlevel.html#gac6e090986a538ce9a8bc5b00fb7ae41a", null ],
    [ "pwr_initialize", "de/def/group__highlevel.html#ga17b0c609321f019c45e5cfc38e4ea54e", null ],
    [ "pwr_is_initialized", "de/def/group__highlevel.html#gaee681e56985ef71f685c01375e0207a2", null ]
];