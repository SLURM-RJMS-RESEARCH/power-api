var structure_8h =
[
    [ "pwr_island_of_cpu", "de/d66/structure_8h.html#a3e351213041100b20e9a470a48c67a49", null ],
    [ "pwr_num_phys_cpus", "de/d66/structure_8h.html#a73dc6f20319d94265b9d52ed741e2837", null ],
    [ "pwr_num_phys_islands", "de/d66/structure_8h.html#a4ffcc23e09cc6560b3de443fa6d2d301", null ]
];