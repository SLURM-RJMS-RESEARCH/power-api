var structpwr__ctx =
[
    [ "emeas", "de/dd9/structpwr__ctx.html#a1fabbfb1b9cd0aff94f8054b0764347f", null ],
    [ "emeas_running", "de/dd9/structpwr__ctx.html#a7990793867d0a773c53ca336e81182cb", null ],
    [ "err_fd", "de/dd9/structpwr__ctx.html#aeab367eb3fe7c7b64e7958fbdeb59eec", null ],
    [ "error", "de/dd9/structpwr__ctx.html#ad43fea61789f90fddadc5ecbe7b280e1", null ],
    [ "event_set", "de/dd9/structpwr__ctx.html#a3684813ff367e3a11cdcaff42a22545d", null ],
    [ "island_throttle_files", "de/dd9/structpwr__ctx.html#a30fea97c6c3576a8392eea51148d59dc", null ],
    [ "module_init", "de/dd9/structpwr__ctx.html#a85660d325c3730a2a29c3dfb80a43d2d", null ],
    [ "num_phys_cpu", "de/dd9/structpwr__ctx.html#a65885a70a662f137c73a1a6a3d4a766d", null ],
    [ "num_phys_islands", "de/dd9/structpwr__ctx.html#ae846189e1dcf05cd2441d80d0517edf6", null ],
    [ "phys_islands", "de/dd9/structpwr__ctx.html#a8073e2cecce89033598e2c6ab9d65e69", null ]
];