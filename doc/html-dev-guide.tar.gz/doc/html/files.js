var files =
[
    [ "ecount.c", null, null ],
    [ "ecount.h", null, null ],
    [ "power_api.c", "d1/d3c/power__api_8c.html", "d1/d3c/power__api_8c" ],
    [ "power_api.h", "d3/d3f/power__api_8h.html", "d3/d3f/power__api_8h" ],
    [ "test_driver.c", null, null ]
];