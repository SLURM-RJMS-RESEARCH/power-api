var files =
[
    [ "dvfs.c", "d7/d6e/dvfs_8c_source.html", null ],
    [ "dvfs.h", "d5/d6a/dvfs_8h.html", "d5/d6a/dvfs_8h" ],
    [ "energy.c", "de/df8/energy_8c_source.html", null ],
    [ "energy.h", "dc/d2b/energy_8h.html", "dc/d2b/energy_8h" ],
    [ "high_level.c", "d0/de3/high__level_8c_source.html", null ],
    [ "high_level.h", "d9/d51/high__level_8h.html", "d9/d51/high__level_8h" ],
    [ "internals.c", "dd/ded/internals_8c_source.html", null ],
    [ "internals.h", "dd/da3/internals_8h.html", "dd/da3/internals_8h" ],
    [ "power-api.h", "dd/d37/power-api_8h_source.html", null ],
    [ "power_api.c", "d1/d3c/power__api_8c.html", "d1/d3c/power__api_8c" ],
    [ "structure.c", "df/d20/structure_8c_source.html", null ],
    [ "structure.h", "de/d66/structure_8h.html", "de/d66/structure_8h" ],
    [ "test_driver.c", "d2/d8b/test__driver_8c_source.html", null ]
];