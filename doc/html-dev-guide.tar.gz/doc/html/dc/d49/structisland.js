var structisland =
[
    [ "agility", "dc/d49/structisland.html#a3f6a8e3226e8df7a971977dfb67e8476", null ],
    [ "cpus", "dc/d49/structisland.html#ab0e5237cb29ff01aa3681437c52cd4b1", null ],
    [ "current_speed_level", "dc/d49/structisland.html#ab50780ee65e8d402839b962e1d85d99b", null ],
    [ "current_voltage", "dc/d49/structisland.html#ab6d31c4082f63841d7c511bb37fb18d6", null ],
    [ "freqs", "dc/d49/structisland.html#a7305b4aeefb923e8acc56df9103ee358", null ],
    [ "id", "dc/d49/structisland.html#a1e9a5cab2a736c2044af6ab6f6260377", null ],
    [ "max_speed_level", "dc/d49/structisland.html#a13d2f40cd8a123fc1141ddf8d74d91c0", null ],
    [ "min_speed_level", "dc/d49/structisland.html#a946ae6b5e38072fa8b01b75f02892213", null ],
    [ "num_cpu", "dc/d49/structisland.html#a729073d30ecfd61a5b4055aa183abd0e", null ],
    [ "num_speed_levels", "dc/d49/structisland.html#a00dc5d84e91186e94366c7ace8f7d273", null ],
    [ "num_voltages", "dc/d49/structisland.html#a58818c582fd79264849c8c998445b34a", null ],
    [ "voltages", "dc/d49/structisland.html#a8cf9f102d49d43130ee28131deb49e3f", null ]
];