var group__modules =
[
    [ "pwr_module_id_t", "dc/dd2/group__modules.html#gaa94bba0a95a36a9f5c1cea5390194ce2", null ],
    [ "pwr_module_id_t", "dc/dd2/group__modules.html#gaeed46d8eca2d6050486b6e5a0b27827c", [
      [ "PWR_MODULE_STRUCT", "dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca8e2e833d2a25141eb866a89718d73a6c", null ],
      [ "PWR_MODULE_DVFS", "dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca89ac8cddfff2f36569f79170e637dbeb", null ],
      [ "PWR_MODULE_ENERGY", "dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca34a98adc4078a1dfcda8dcf2bdf93e50", null ],
      [ "PWR_MODULE_HIGH_LEVEL", "dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca197a74d7a1daa555cda7dce185311df5", null ],
      [ "PWR_NB_MODULES", "dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827caf2ea7ed58366ebe1f818b5f803c55298", null ]
    ] ]
];