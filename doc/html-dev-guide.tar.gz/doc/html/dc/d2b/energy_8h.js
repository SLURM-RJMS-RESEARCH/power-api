var energy_8h =
[
    [ "pwr_emeas_t", "d3/d10/structpwr__emeas__t.html", "d3/d10/structpwr__emeas__t" ],
    [ "pwr_start_energy_count", "dc/d2b/energy_8h.html#a1e757fa76b9bdc33b54c2719ccdcc0e8", null ],
    [ "pwr_stop_energy_count", "dc/d2b/energy_8h.html#af41eb9330c8d708be21111b1b4c1966b", null ]
];