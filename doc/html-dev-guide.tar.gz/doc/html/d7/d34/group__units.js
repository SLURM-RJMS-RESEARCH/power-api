var group__units =
[
    [ "agility_t", "d7/d34/group__units.html#gafdcb27e6a974f93523b83a8591f55d64", null ],
    [ "efficiency_t", "d7/d34/group__units.html#gae15265a18d96d2c89df35bd06f48be5f", null ],
    [ "energy_t", "d7/d34/group__units.html#ga17e0621230dceff0875f8cb3332814d4", null ],
    [ "freq_t", "d7/d34/group__units.html#gac90f4f5bbd20c291dcfa85f165632f1b", null ],
    [ "power_t", "d7/d34/group__units.html#gadf7637fee6cababa1b3a7e5f96e67ce3", null ],
    [ "speed_level_t", "d7/d34/group__units.html#ga20d9e61ca6f5e388fd5c1bc3d8b7600b", null ],
    [ "speed_t", "d7/d34/group__units.html#gaeb7509232e57cd41b056a651627cc82a", null ],
    [ "voltage_t", "d7/d34/group__units.html#gad413ffa288d3a3dd4f276daac7e32124", null ]
];