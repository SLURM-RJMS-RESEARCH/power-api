var dvfs_8h =
[
    [ "pwr_agility", "d5/d6a/dvfs_8h.html#aec520b4dd3353392d2ea8baccf564297", null ],
    [ "pwr_current_speed_level", "d5/d6a/dvfs_8h.html#a75e109e1e97faa936f75d32ad05f89ba", null ],
    [ "pwr_increase_speed_level", "d5/d6a/dvfs_8h.html#ae3faded356ad8d7f55958344a5e1a890", null ],
    [ "pwr_num_speed_levels", "d5/d6a/dvfs_8h.html#a8589e201b3b93e943c76df70d9788d5e", null ],
    [ "pwr_request_speed_level", "d5/d6a/dvfs_8h.html#a25e159da12ab25aca7300c084bb41189", null ]
];