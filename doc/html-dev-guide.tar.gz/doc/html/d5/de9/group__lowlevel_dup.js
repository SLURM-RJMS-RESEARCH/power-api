var group__lowlevel_dup =
[
    [ "pwr_agility", "d5/de9/group__lowlevel.html#ga6e6e9baf782949fcd23521cf5b8fa78d", null ],
    [ "pwr_current_speed_level", "d5/de9/group__lowlevel.html#ga4630928c1bdf702870304f10df4e69ca", null ],
    [ "pwr_energy_counter", "d5/de9/group__lowlevel.html#ga4acc21a71b65f224952f6ba9ca6d38b8", null ],
    [ "pwr_islands", "d5/de9/group__lowlevel.html#ga1aec3d44dff94241c166730cc89e3a68", null ],
    [ "pwr_modify_speed_level", "d5/de9/group__lowlevel.html#ga817b8cadad98fe034346750caa5234c2", null ],
    [ "pwr_modify_voltage", "d5/de9/group__lowlevel.html#gaa4e7a362a23e45d2f6f1929ae54abfb6", null ],
    [ "pwr_num_islands", "d5/de9/group__lowlevel.html#ga84a42f8b666cd4897d5192b53f7701ca", null ],
    [ "pwr_num_speed_levels", "d5/de9/group__lowlevel.html#ga6c6f38b6b73d1eee98464565e631c126", null ],
    [ "pwr_request_speed_level", "d5/de9/group__lowlevel.html#ga00d8c45101de8469eaa8579a8cdfeccb", null ]
];