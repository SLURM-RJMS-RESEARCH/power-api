var searchData=
[
  ['initialization_20code',['Initialization code',['../d9/d54/group__init.html',1,'']]],
  ['internals_2eh',['internals.h',['../dd/da3/internals_8h.html',1,'']]]
];
