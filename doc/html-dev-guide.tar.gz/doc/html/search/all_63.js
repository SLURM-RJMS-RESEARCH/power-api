var searchData=
[
  ['compare_5fcpu_5fid',['compare_cpu_id',['../d1/d3c/power__api_8c.html#a367a7b61bc22af38389e83eebceee3c4',1,'power_api.c']]],
  ['compare_5ffreq',['compare_freq',['../d1/d3c/power__api_8c.html#a0bd29328ed8fd41a667d0836f292a686',1,'power_api.c']]],
  ['cpu_5fid_5ft',['cpu_id_t',['../d1/d3c/power__api_8c.html#a2c0cba84d116dabf142e1a0ebb2f3c90',1,'power_api.c']]],
  ['cpus',['cpus',['../dc/d49/structisland.html#ab0e5237cb29ff01aa3681437c52cd4b1',1,'island']]],
  ['current_5fspeed_5flevel',['current_speed_level',['../dc/d49/structisland.html#ab50780ee65e8d402839b962e1d85d99b',1,'island']]],
  ['current_5fvoltage',['current_voltage',['../dc/d49/structisland.html#ab6d31c4082f63841d7c511bb37fb18d6',1,'island']]]
];
