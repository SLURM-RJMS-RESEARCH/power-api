var searchData=
[
  ['pwr_5fmodule_5fdvfs',['PWR_MODULE_DVFS',['../dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca89ac8cddfff2f36569f79170e637dbeb',1,'power-api.h']]],
  ['pwr_5fmodule_5fenergy',['PWR_MODULE_ENERGY',['../dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca34a98adc4078a1dfcda8dcf2bdf93e50',1,'power-api.h']]],
  ['pwr_5fmodule_5fhigh_5flevel',['PWR_MODULE_HIGH_LEVEL',['../dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca197a74d7a1daa555cda7dce185311df5',1,'power-api.h']]],
  ['pwr_5fmodule_5fstruct',['PWR_MODULE_STRUCT',['../dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827ca8e2e833d2a25141eb866a89718d73a6c',1,'power-api.h']]],
  ['pwr_5fnb_5fmodules',['PWR_NB_MODULES',['../dc/dd2/group__modules.html#ggaeed46d8eca2d6050486b6e5a0b27827caf2ea7ed58366ebe1f818b5f803c55298',1,'power-api.h']]]
];
