var searchData=
[
  ['init_5fenergy',['init_energy',['../dd/da3/internals_8h.html#a88d17493f557c4f8b69f3d68d38a587b',1,'energy.c']]],
  ['init_5fspeed_5flevels',['init_speed_levels',['../dd/da3/internals_8h.html#aabd446883e3dfacb5c5327a06b508cf4',1,'dvfs.c']]],
  ['init_5fstruct_5fmodule',['init_struct_module',['../dd/da3/internals_8h.html#af9ba1c381cd94c00d7a9c7d11358e35d',1,'structure.c']]]
];
