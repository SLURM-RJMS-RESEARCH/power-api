var searchData=
[
  ['sort_5fand_5fcast_5ffreqs',['sort_and_cast_freqs',['../d1/d3c/power__api_8c.html#ac9b99e7c4a7ac5d1ff4be11ec85c1ca6',1,'power_api.c']]],
  ['sysfs_5ffilename',['sysfs_filename',['../d1/d3c/power__api_8c.html#ae91a0958c71e77903392380deb6147c2',1,'power_api.c']]]
];
