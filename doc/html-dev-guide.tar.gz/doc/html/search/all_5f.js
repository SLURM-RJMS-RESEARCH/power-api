var searchData=
[
  ['_5fposix_5fc_5fsource',['_POSIX_C_SOURCE',['../d1/d3c/power__api_8c.html#a3024ccd4a9af5109d24e6c57565d74a1',1,'power_api.c']]]
];
