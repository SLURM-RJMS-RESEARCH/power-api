var searchData=
[
  ['agility',['agility',['../dc/d49/structisland.html#a3f6a8e3226e8df7a971977dfb67e8476',1,'island']]],
  ['agility_5ft',['agility_t',['../d7/d34/group__units.html#gafdcb27e6a974f93523b83a8591f55d64',1,'power_api.h']]]
];
