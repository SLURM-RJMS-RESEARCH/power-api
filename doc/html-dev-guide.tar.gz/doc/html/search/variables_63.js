var searchData=
[
  ['cpus',['cpus',['../dc/d49/structisland.html#ab0e5237cb29ff01aa3681437c52cd4b1',1,'island']]],
  ['current_5fspeed_5flevel',['current_speed_level',['../dc/d49/structisland.html#ab50780ee65e8d402839b962e1d85d99b',1,'island']]],
  ['current_5fvoltage',['current_voltage',['../dc/d49/structisland.html#ab6d31c4082f63841d7c511bb37fb18d6',1,'island']]]
];
