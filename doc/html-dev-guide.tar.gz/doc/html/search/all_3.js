var searchData=
[
  ['freq_5ft',['freq_t',['../d7/d34/group__units.html#gac90f4f5bbd20c291dcfa85f165632f1b',1,'power-api.h']]]
];
