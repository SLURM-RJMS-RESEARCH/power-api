var searchData=
[
  ['compare_5fcpu_5fid',['compare_cpu_id',['../d1/d3c/power__api_8c.html#a367a7b61bc22af38389e83eebceee3c4',1,'power_api.c']]],
  ['compare_5ffreq',['compare_freq',['../d1/d3c/power__api_8c.html#a0bd29328ed8fd41a667d0836f292a686',1,'power_api.c']]]
];
