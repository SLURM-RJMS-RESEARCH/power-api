var searchData=
[
  ['power_5ft',['power_t',['../d7/d34/group__units.html#gadf7637fee6cababa1b3a7e5f96e67ce3',1,'power_api.h']]]
];
