var searchData=
[
  ['power_5fapi_2ec',['power_api.c',['../d1/d3c/power__api_8c.html',1,'']]]
];
