var searchData=
[
  ['power_5fapi_2ec',['power_api.c',['../d1/d3c/power__api_8c.html',1,'']]],
  ['power_5fapi_2eh',['power_api.h',['../d3/d3f/power__api_8h.html',1,'']]]
];
