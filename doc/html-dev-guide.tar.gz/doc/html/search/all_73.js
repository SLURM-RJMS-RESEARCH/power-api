var searchData=
[
  ['scheduling_5fpolicy_5ft',['scheduling_policy_t',['../dc/d98/group__hli.html#gadb59d2ac8c3cc72f2825a6ff2d8106fe',1,'power_api.h']]],
  ['sort_5fand_5fcast_5ffreqs',['sort_and_cast_freqs',['../d1/d3c/power__api_8c.html#ac9b99e7c4a7ac5d1ff4be11ec85c1ca6',1,'power_api.c']]],
  ['speed',['speed',['../d2/d14/structhw__behavior.html#a77e76354533e34460e9f05e334370869',1,'hw_behavior']]],
  ['speed_5flevel',['speed_level',['../d2/d14/structhw__behavior.html#a2a245a764551a3e7c3ae7ccdcdeda984',1,'hw_behavior']]],
  ['speed_5flevel_5ft',['speed_level_t',['../d7/d34/group__units.html#ga20d9e61ca6f5e388fd5c1bc3d8b7600b',1,'power_api.h']]],
  ['speed_5fpolicy_5ft',['speed_policy_t',['../dc/d98/group__hli.html#ga51d7d2cd039d9380ea9fa04cd58be165',1,'power_api.h']]],
  ['speed_5ft',['speed_t',['../d7/d34/group__units.html#gaeb7509232e57cd41b056a651627cc82a',1,'power_api.h']]],
  ['sysfs_5ffilename',['sysfs_filename',['../d1/d3c/power__api_8c.html#ae91a0958c71e77903392380deb6147c2',1,'power_api.c']]]
];
