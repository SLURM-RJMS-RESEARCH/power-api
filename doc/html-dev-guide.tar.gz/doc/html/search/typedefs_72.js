var searchData=
[
  ['retval_5ft',['retval_t',['../d6/d87/group__errors.html#ga533af222956cd2ff6748ce10c282846d',1,'power_api.h']]]
];
