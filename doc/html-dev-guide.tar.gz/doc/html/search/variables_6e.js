var searchData=
[
  ['num_5fcpu',['num_cpu',['../dc/d49/structisland.html#a729073d30ecfd61a5b4055aa183abd0e',1,'island::num_cpu()'],['../d1/d3c/power__api_8c.html#ac525d2b6165223b439321b9a35baadb4',1,'num_cpu():&#160;power_api.c']]],
  ['num_5fislands',['num_islands',['../d1/d3c/power__api_8c.html#a02be0697320945c33a788b68ba069adb',1,'power_api.c']]],
  ['num_5fspeed_5flevels',['num_speed_levels',['../dc/d49/structisland.html#a00dc5d84e91186e94366c7ace8f7d273',1,'island']]],
  ['num_5ftuples',['num_tuples',['../d2/d14/structhw__behavior.html#ac83f8164c20d9aa20c462fd8fd990a11',1,'hw_behavior']]],
  ['num_5fvoltages',['num_voltages',['../dc/d49/structisland.html#a58818c582fd79264849c8c998445b34a',1,'island']]]
];
