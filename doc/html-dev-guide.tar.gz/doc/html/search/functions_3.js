var searchData=
[
  ['sysfs_5ffilename',['sysfs_filename',['../d1/d3c/power__api_8c.html#a5e90fde5437178cce4b98a6e0a0773ff',1,'sysfs_filename(unsigned long cpu_id, const char *filename):&#160;power_api.c'],['../dd/da3/internals_8h.html#a5e90fde5437178cce4b98a6e0a0773ff',1,'sysfs_filename(unsigned long cpu_id, const char *filename):&#160;power_api.c']]]
];
