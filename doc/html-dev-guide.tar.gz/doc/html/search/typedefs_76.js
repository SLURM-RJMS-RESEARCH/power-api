var searchData=
[
  ['voltage_5ft',['voltage_t',['../d7/d34/group__units.html#gad413ffa288d3a3dd4f276daac7e32124',1,'power_api.h']]]
];
