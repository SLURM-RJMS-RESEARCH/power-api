var searchData=
[
  ['values',['values',['../d3/d10/structpwr__emeas__t.html#aa98aeff03e7d721ccbfe0cd9adbfbe58',1,'pwr_emeas_t']]],
  ['voltages',['voltages',['../d4/d71/structphys__island.html#a91633e81aee2a95a0845826423bb31ff',1,'phys_island']]]
];
