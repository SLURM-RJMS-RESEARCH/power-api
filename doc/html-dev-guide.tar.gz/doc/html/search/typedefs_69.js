var searchData=
[
  ['island_5fid_5ft',['island_id_t',['../da/d2d/group__id.html#gaffad25893741d02d0172e41998fe9d45',1,'power_api.h']]],
  ['island_5ft',['island_t',['../d1/d3c/power__api_8c.html#a6a4f6d3e6761efc1ad4e3235e6409852',1,'power_api.c']]]
];
