var searchData=
[
  ['pwr_5fmodule_5fid_5ft',['pwr_module_id_t',['../dc/dd2/group__modules.html#gaeed46d8eca2d6050486b6e5a0b27827c',1,'power-api.h']]]
];
