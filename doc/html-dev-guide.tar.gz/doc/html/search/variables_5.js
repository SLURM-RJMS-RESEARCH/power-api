var searchData=
[
  ['phys_5fislands',['phys_islands',['../de/dd9/structpwr__ctx.html#a8073e2cecce89033598e2c6ab9d65e69',1,'pwr_ctx']]]
];
