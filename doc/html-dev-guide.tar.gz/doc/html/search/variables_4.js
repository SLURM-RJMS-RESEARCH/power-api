var searchData=
[
  ['names',['names',['../d3/d10/structpwr__emeas__t.html#a9529725765a6ad5b7783528e7a68e962',1,'pwr_emeas_t']]],
  ['nbvalues',['nbValues',['../d3/d10/structpwr__emeas__t.html#a8cb45a46026ec0569a061c971792423b',1,'pwr_emeas_t']]],
  ['num_5fphys_5fcpu',['num_phys_cpu',['../de/dd9/structpwr__ctx.html#a65885a70a662f137c73a1a6a3d4a766d',1,'pwr_ctx']]],
  ['num_5fphys_5fislands',['num_phys_islands',['../de/dd9/structpwr__ctx.html#ae846189e1dcf05cd2441d80d0517edf6',1,'pwr_ctx']]]
];
