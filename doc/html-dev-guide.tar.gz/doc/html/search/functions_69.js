var searchData=
[
  ['init_5fcpu',['init_cpu',['../d1/d3c/power__api_8c.html#aca90506e8278787513736353f0369050',1,'power_api.c']]],
  ['init_5fislands',['init_islands',['../d1/d3c/power__api_8c.html#a5bf19f2424b10a38d8bb6fa0f5509e58',1,'power_api.c']]],
  ['init_5fspeed_5flevels',['init_speed_levels',['../d1/d3c/power__api_8c.html#a6f08743571e4e265796f9beb046355a0',1,'power_api.c']]],
  ['island_5fdeep_5feq',['island_deep_eq',['../d1/d3c/power__api_8c.html#a7882634de928f4d75a918892cb194642',1,'power_api.c']]]
];
