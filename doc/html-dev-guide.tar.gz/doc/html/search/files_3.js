var searchData=
[
  ['internals_2eh',['internals.h',['../dd/da3/internals_8h.html',1,'']]]
];
