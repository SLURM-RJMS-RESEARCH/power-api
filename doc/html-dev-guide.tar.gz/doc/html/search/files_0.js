var searchData=
[
  ['dvfs_2eh',['dvfs.h',['../d5/d6a/dvfs_8h.html',1,'']]]
];
