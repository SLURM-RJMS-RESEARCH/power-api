var searchData=
[
  ['pwr_5fagility',['pwr_agility',['../d5/d6a/dvfs_8h.html#aec520b4dd3353392d2ea8baccf564297',1,'dvfs.c']]],
  ['pwr_5fcurrent_5fspeed_5flevel',['pwr_current_speed_level',['../d5/d6a/dvfs_8h.html#a75e109e1e97faa936f75d32ad05f89ba',1,'dvfs.c']]],
  ['pwr_5fefficiency',['pwr_efficiency',['../d9/d51/high__level_8h.html#afd88759f6fb6b946ef659c542b346102',1,'high_level.c']]],
  ['pwr_5ferror',['pwr_error',['../d9/d54/group__init.html#ga7038c748f459c4cb1b16cf44582752eb',1,'pwr_error(const pwr_ctx_t *ctx):&#160;power_api.c'],['../d9/d54/group__init.html#ga7038c748f459c4cb1b16cf44582752eb',1,'pwr_error(const pwr_ctx_t *ctx):&#160;power_api.c']]],
  ['pwr_5ffinalize',['pwr_finalize',['../d9/d54/group__init.html#ga301c96a243cc73baec7c7c366f0283d7',1,'pwr_finalize(pwr_ctx_t *ctx):&#160;power_api.c'],['../d9/d54/group__init.html#ga301c96a243cc73baec7c7c366f0283d7',1,'pwr_finalize(pwr_ctx_t *ctx):&#160;power_api.c']]],
  ['pwr_5fincrease_5fspeed_5flevel',['pwr_increase_speed_level',['../d5/d6a/dvfs_8h.html#ae3faded356ad8d7f55958344a5e1a890',1,'dvfs.c']]],
  ['pwr_5fincrease_5fvoltage',['pwr_increase_voltage',['../d9/d51/high__level_8h.html#a11f7f4e39cbdb185549e047648237dae',1,'high_level.c']]],
  ['pwr_5finitialize',['pwr_initialize',['../d9/d54/group__init.html#gab97161204e9894a250dd4da2257ad66c',1,'pwr_initialize(void *hw_behavior, void *speed_policy, void *scheduling_policy):&#160;power_api.c'],['../d9/d54/group__init.html#gab97161204e9894a250dd4da2257ad66c',1,'pwr_initialize(void *hw_behavior, void *speed_policy, void *scheduling_policy):&#160;power_api.c']]],
  ['pwr_5fis_5finitialized',['pwr_is_initialized',['../d9/d54/group__init.html#gab777603617d5f5f8f88dda2c94102efe',1,'pwr_is_initialized(const pwr_ctx_t *ctx, const pwr_module_id_t module):&#160;power_api.c'],['../d9/d54/group__init.html#gab777603617d5f5f8f88dda2c94102efe',1,'pwr_is_initialized(const pwr_ctx_t *ctx, const pwr_module_id_t module):&#160;power_api.c']]],
  ['pwr_5fisland_5fof_5fcpu',['pwr_island_of_cpu',['../de/d66/structure_8h.html#a3e351213041100b20e9a470a48c67a49',1,'structure.c']]],
  ['pwr_5fnum_5fphys_5fcpus',['pwr_num_phys_cpus',['../de/d66/structure_8h.html#a73dc6f20319d94265b9d52ed741e2837',1,'structure.c']]],
  ['pwr_5fnum_5fphys_5fislands',['pwr_num_phys_islands',['../de/d66/structure_8h.html#a4ffcc23e09cc6560b3de443fa6d2d301',1,'structure.c']]],
  ['pwr_5fnum_5fspeed_5flevels',['pwr_num_speed_levels',['../d5/d6a/dvfs_8h.html#a8589e201b3b93e943c76df70d9788d5e',1,'dvfs.c']]],
  ['pwr_5frequest_5fspeed_5flevel',['pwr_request_speed_level',['../d5/d6a/dvfs_8h.html#a25e159da12ab25aca7300c084bb41189',1,'dvfs.c']]],
  ['pwr_5fset_5fpower_5fpriority',['pwr_set_power_priority',['../d9/d51/high__level_8h.html#a22d6f277f5a19020de4756623a640205',1,'high_level.c']]],
  ['pwr_5fset_5fspeed_5fpriority',['pwr_set_speed_priority',['../d9/d51/high__level_8h.html#aba20576a7e1e89ec7a0bc4423639db20',1,'high_level.c']]],
  ['pwr_5fstart_5fenergy_5fcount',['pwr_start_energy_count',['../dc/d2b/energy_8h.html#a1e757fa76b9bdc33b54c2719ccdcc0e8',1,'energy.c']]],
  ['pwr_5fstop_5fenergy_5fcount',['pwr_stop_energy_count',['../dc/d2b/energy_8h.html#af41eb9330c8d708be21111b1b4c1966b',1,'energy.c']]],
  ['pwr_5fstrerror',['pwr_strerror',['../d9/d54/group__init.html#ga3152e7b41e6eebe7a845ba3741d80123',1,'pwr_strerror(const pwr_ctx_t *ctx):&#160;power_api.c'],['../d9/d54/group__init.html#ga3152e7b41e6eebe7a845ba3741d80123',1,'pwr_strerror(const pwr_ctx_t *ctx):&#160;power_api.c']]]
];
