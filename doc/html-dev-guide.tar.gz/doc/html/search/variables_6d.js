var searchData=
[
  ['max_5fspeed_5flevel',['max_speed_level',['../dc/d49/structisland.html#a13d2f40cd8a123fc1141ddf8d74d91c0',1,'island']]],
  ['min_5fspeed_5flevel',['min_speed_level',['../dc/d49/structisland.html#a946ae6b5e38072fa8b01b75f02892213',1,'island']]]
];
