var searchData=
[
  ['efficiency_5ft',['efficiency_t',['../d7/d34/group__units.html#gae15265a18d96d2c89df35bd06f48be5f',1,'power-api.h']]],
  ['energy_5ft',['energy_t',['../d7/d34/group__units.html#ga17e0621230dceff0875f8cb3332814d4',1,'power-api.h']]]
];
