var searchData=
[
  ['duration',['duration',['../d3/d10/structpwr__emeas__t.html#a11b4f61f7dadc5e76129e1d30bb9ecc1',1,'pwr_emeas_t']]],
  ['dvfs_2eh',['dvfs.h',['../d5/d6a/dvfs_8h.html',1,'']]]
];
