var searchData=
[
  ['cpu_5fid_5ft',['cpu_id_t',['../d1/d3c/power__api_8c.html#a2c0cba84d116dabf142e1a0ebb2f3c90',1,'power_api.c']]]
];
