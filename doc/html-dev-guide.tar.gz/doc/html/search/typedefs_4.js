var searchData=
[
  ['speed_5flevel_5ft',['speed_level_t',['../d7/d34/group__units.html#ga20d9e61ca6f5e388fd5c1bc3d8b7600b',1,'power-api.h']]],
  ['speed_5ft',['speed_t',['../d7/d34/group__units.html#gaeb7509232e57cd41b056a651627cc82a',1,'power-api.h']]]
];
