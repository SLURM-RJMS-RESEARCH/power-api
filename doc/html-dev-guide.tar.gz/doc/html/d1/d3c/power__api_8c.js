var power__api_8c =
[
    [ "pwr_error", "d1/d3c/power__api_8c.html#ga7038c748f459c4cb1b16cf44582752eb", null ],
    [ "pwr_finalize", "d1/d3c/power__api_8c.html#ga301c96a243cc73baec7c7c366f0283d7", null ],
    [ "pwr_initialize", "d1/d3c/power__api_8c.html#gab97161204e9894a250dd4da2257ad66c", null ],
    [ "pwr_is_initialized", "d1/d3c/power__api_8c.html#gab777603617d5f5f8f88dda2c94102efe", null ],
    [ "pwr_strerror", "d1/d3c/power__api_8c.html#ga3152e7b41e6eebe7a845ba3741d80123", null ],
    [ "sysfs_filename", "d1/d3c/power__api_8c.html#a5e90fde5437178cce4b98a6e0a0773ff", null ]
];