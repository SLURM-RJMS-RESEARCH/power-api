var structe__data =
[
    [ "names", "d9/d46/structe__data.html#aef1363e3163136fcbfee72e22e03ff6d", null ],
    [ "start_time_ns", "d9/d46/structe__data.html#a775d4c84a79e88bc2084afa4247d6e81", null ],
    [ "stop_time_ns", "d9/d46/structe__data.html#a9ad2c467cc8f4f3d17ca2357f6776a6f", null ],
    [ "units", "d9/d46/structe__data.html#a10cfb2b10b0c3a58e0191fd298b8985e", null ],
    [ "values", "d9/d46/structe__data.html#a04be10dc12a3ef95347a659214998a6e", null ]
];