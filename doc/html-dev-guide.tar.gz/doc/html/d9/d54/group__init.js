var group__init =
[
    [ "pwr_error", "d9/d54/group__init.html#ga7038c748f459c4cb1b16cf44582752eb", null ],
    [ "pwr_finalize", "d9/d54/group__init.html#ga301c96a243cc73baec7c7c366f0283d7", null ],
    [ "pwr_initialize", "d9/d54/group__init.html#gab97161204e9894a250dd4da2257ad66c", null ],
    [ "pwr_is_initialized", "d9/d54/group__init.html#gab777603617d5f5f8f88dda2c94102efe", null ],
    [ "pwr_strerror", "d9/d54/group__init.html#ga3152e7b41e6eebe7a845ba3741d80123", null ]
];