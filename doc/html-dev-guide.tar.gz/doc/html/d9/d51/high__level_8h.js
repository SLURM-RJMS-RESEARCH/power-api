var high__level_8h =
[
    [ "pwr_efficiency", "d9/d51/high__level_8h.html#afd88759f6fb6b946ef659c542b346102", null ],
    [ "pwr_increase_voltage", "d9/d51/high__level_8h.html#a11f7f4e39cbdb185549e047648237dae", null ],
    [ "pwr_set_power_priority", "d9/d51/high__level_8h.html#a22d6f277f5a19020de4756623a640205", null ],
    [ "pwr_set_speed_priority", "d9/d51/high__level_8h.html#aba20576a7e1e89ec7a0bc4423639db20", null ]
];