var structphys__island =
[
    [ "agility", "d4/d71/structphys__island.html#a7dba884da84616a1e14897039270c62c", null ],
    [ "cpus", "d4/d71/structphys__island.html#aaa5f93eea25e611fc46076cd3dee0ccb", null ],
    [ "current_speed_level", "d4/d71/structphys__island.html#a294a823d9211653967cbaf4788cb3dcb", null ],
    [ "current_voltage", "d4/d71/structphys__island.html#aac22f709adc5fc8350858a0ae9247b13", null ],
    [ "freqs", "d4/d71/structphys__island.html#ab0170e10a11469b1c22a0ce3ca899d45", null ],
    [ "max_speed_level", "d4/d71/structphys__island.html#a2727eb162d612dfc5eac4d62fe816e97", null ],
    [ "min_speed_level", "d4/d71/structphys__island.html#aa9ab598ebab2bc3cafb9e15d485e7099", null ],
    [ "num_cpu", "d4/d71/structphys__island.html#acc18c207c87ccd22e03252ab927690fc", null ],
    [ "num_speed_levels", "d4/d71/structphys__island.html#aaba81f4c48a089b29a51ccdfd8955ad0", null ],
    [ "num_voltages", "d4/d71/structphys__island.html#a7a610670f3d18f3f05cf6e90d05e6c3d", null ],
    [ "voltages", "d4/d71/structphys__island.html#a91633e81aee2a95a0845826423bb31ff", null ]
];